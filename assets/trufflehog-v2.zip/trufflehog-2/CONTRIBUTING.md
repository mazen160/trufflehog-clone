# Contribution guidelines

Hey folks. If possible try to keep PR's scoped to one feature, and add tests for new features.
